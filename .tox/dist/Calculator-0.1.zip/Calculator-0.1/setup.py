from distutils.core import setup

setup(
    name='Calculator',
    version='0.1',
    packages=[''],
    url='',
    license='',
    author='Denis Salamanca',
    author_email='-',
    description=''
)